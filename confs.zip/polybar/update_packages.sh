#!/bin/bash
kitty -- bash -c "sudo apt-get update | lolcat && sudo apt-get upgrade -y | lolcat; echo ; echo ; read -p 'Press Enter to exit'"
