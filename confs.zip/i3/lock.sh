#!/bin/bash
i3lock -c 000000
