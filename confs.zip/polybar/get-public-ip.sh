#!/bin/bash

# Use curl to fetch your public IP address from ipinfo.io
curl -s https://ipinfo.io/ip
