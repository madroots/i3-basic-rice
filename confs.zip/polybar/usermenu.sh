#!/bin/bash

username=$(whoami)  # Get the current username

# Display the dropdown menu
echo "%{F#0099FF} $username%{F-}"  # Replace  with the Font Awesome user icon or any icon you prefer
echo "---"
echo " Log Out | pkill -KILL -u $username"
echo " Shutdown | systemctl poweroff"
echo " Reboot | systemctl reboot"
