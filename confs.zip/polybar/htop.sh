#!/bin/bash
kitty -- bash -c "htop"
