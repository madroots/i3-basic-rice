#!/bin/bash

if [ "$1" = "click" ]; then
    # On left-click, display a menu of available Wi-Fi networks and let the user choose one to connect to.
    networks=$(nmcli device wifi list | awk 'NR>1{print $2}')
    selected=$(echo "$networks" | rofi -dmenu -p "Select a Wi-Fi network:")

    if [ -n "$selected" ]; then
        sudo nmcli device wifi connect "$selected"
    fi
else
    # Display the current Wi-Fi connection status.
    if nmcli -t -f DEVICE,STATE,SSID dev | grep -q "wlp2s0:connected"; then
        ssid=$(nmcli -t -f DEVICE,SSID dev | awk -F: '/wlp2s0:connected/{print $2}')
        echo "$ssid"
    else
        echo "Not Connected"
    fi
fi
